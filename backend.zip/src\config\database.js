const dbPath = process.env.NODE_ENV === 'production'
  ? '/home/diamonan/plg.et/backend/data/pos.db'
  : './data/pos.db';

// ... rest of your database configuration ... 